# This file is auto-generated during build from root pyproject.toml
# Do not edit manually

__version__ = "2.0.0rc2"
